#include <iostream>
#include <string>
#include <time.h>
#include <algorithm>
#include <random>
#include <cstdlib>
#include "Prefix_Trie.h"

using namespace std;

int main(int argc, char **argv) 
{
	char *path1 = argv[1];
	
	Prefix_Trie p_trie = Prefix_Trie(path1);
    p_trie.read_genome_data();

	clock_t start_time, end_time;
	double total_time_taken = 0;

    p_trie.generateFragment(5000, 0);
    p_trie.generateFragment(50000, 0);
    p_trie.generateFragment(100000, 0);
    p_trie.generateFragment(1000000, 0);
    
    cout << "Introducing 0.05 mutation error into the fragments" << endl << endl;
    
    p_trie.generateFragment(5000, 1);
    p_trie.generateFragment(50000, 1);
    p_trie.generateFragment(100000, 1);
    p_trie.generateFragment(1000000, 1);
    
    return 0;
}