#ifndef PREFIX_TRIE
#define PREFIX_TRIE

#include <iostream>
#include <string>

using namespace std;

// defining the TrieNode
struct TrieNode
{
    TrieNode *A = NULL;
    TrieNode *C = NULL;
    TrieNode *G = NULL;
    TrieNode *T = NULL;
};

class Prefix_Trie
{
public:
    char *genome_buffer, *genome_file_path;
    long long int counter = 0, genome_buffer_length = 0, number_of_hits = 0;

    // defining the stackNode
    struct stackNode
    {
        TrieNode *node;
        string usedCharacters;
        string leftCharacters;
        int mismatches;
        stackNode *next = NULL;
    };

    TrieNode *root;
    stackNode *top_of_stack;

    Prefix_Trie();

    Prefix_Trie(char *path1);

    TrieNode *create();

    void find_genome_size();

    void read_genome_data();

    void generateFragment(long long int size, int flag);

    long long int traverseGenome(string kmer);

    void add(string word);

    ~Prefix_Trie();
};

#endif