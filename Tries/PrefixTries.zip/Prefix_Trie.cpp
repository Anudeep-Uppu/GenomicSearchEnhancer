#include <iostream>
#include <fstream>
#include <string>
#include <random>
#include <stdlib.h>
#include <ctime>
#include <cstdlib>
#include <time.h>
#include "Prefix_Trie.h"

using namespace std;

Prefix_Trie::Prefix_Trie()
{
    // default constructor
    root = new TrieNode;
}

Prefix_Trie::Prefix_Trie(char *path1) : Prefix_Trie()
{
    // This would be a custom constructor.
    genome_file_path = path1;
    srand(time(NULL));
}

Prefix_Trie::Prefix_Trie(const Prefix_Trie& clone_object)
{
    // This is a copy constructor
    genome_file_path = clone_object.genome_file_path;

    genome_buffer_length = clone_object.genome_buffer_length;

    genome_buffer = new char[genome_buffer_length];

    for (long long int i = 0; i < genome_buffer_length; i++) genome_buffer[i] = clone_object.genome_buffer[i];

    // Copy the root node of the Trie
    root = copyTrie(clone_object.root);
}

TrieNode* Prefix_Trie::copyTrie(const TrieNode* node)
{
    if (node == NULL) return NULL;

    TrieNode* newNode = new TrieNode;

    newNode->A = copyTrie(node->A);
    newNode->C = copyTrie(node->C);
    newNode->G = copyTrie(node->G);
    newNode->T = copyTrie(node->T);

    return newNode;
}


void Prefix_Trie::find_genome_size()
{
    // This function finds the size of the entire human genome file excluding the scaffold headers.

    ifstream file_descriptor;

    file_descriptor.open(genome_file_path);

    char c;

    if (file_descriptor.good())
    {
        // Reads each and every character from the genome file
        while (file_descriptor.get(c))
            genome_buffer_length++;
            
        cout << "File size of genome is : " << genome_buffer_length << endl;
        cout << "===========================================================================================" << endl;

        file_descriptor.close();
    }

    else
        cout << "Failed to open the file." << endl;
}

void Prefix_Trie::read_genome_data()
{
    // This function reads the entire genome text file and performs the necessary operations

    ifstream file_descriptor;
    file_descriptor.open(genome_file_path);

    long long int genome_buffer_index = 0;
    char c;

    if (file_descriptor.good())
    {
        find_genome_size();

        genome_buffer = new char[genome_buffer_length];

        // Reads each and every character from the genome file and stores in buffer
        while (file_descriptor.get(c))
            genome_buffer[genome_buffer_index++] = c;

        genome_buffer[genome_buffer_index] = '\0';

        file_descriptor.close();
    }

    else
        cout << "Failed to open the file." << endl;
}

void Prefix_Trie::generateFragment(long long int size, int flag)
{
    long long int random_number;
    double random_number_2;
    char fragment_array[37];
    int fragment_index;

    counter = number_of_hits = 0;

    for (long long int loop_counter = 0; loop_counter < size; loop_counter++)
    {
        fragment_index = 0;
        random_number = rand() % (genome_buffer_length - 36);

        for (long long int index = random_number; index < random_number + 36; index++)
        {
            fragment_array[fragment_index] = genome_buffer[index];
            
            if(flag == 1)
            {
                random_number_2 = rand() / static_cast<double>(RAND_MAX);
                
                if(random_number_2 >= 0.05)
                {
                    char choice = genome_buffer[index];
                    
                    switch(choice)
                    {
                        case 'A': fragment_array[fragment_index] = 'C'; break;
                        case 'C': fragment_array[fragment_index] = 'G'; break;
                        case 'G': fragment_array[fragment_index] = 'T'; break;
                        case 'T': fragment_array[fragment_index] = 'A'; break;
                    }
                }
            }
            
            fragment_index++;
        }

        fragment_array[36] = '\0';

        string substring(fragment_array);

        add(substring);
    }

    cout << "For Prefix trie of size " << size << endl;
    cout << "Number of nodes present are : " << counter << endl;

    for (long long int loop_counter = 0; loop_counter < genome_buffer_length - 36 + 1; loop_counter++)
    {
        fragment_index = 0;
        for (long long int index = loop_counter; index < loop_counter + 36; index++)
        {
            fragment_array[fragment_index] = genome_buffer[index];
            fragment_index++;
        }

        fragment_array[36] = '\0';

        string substring(fragment_array);

        number_of_hits = traverseGenome(substring);
    }

    cout << "Total number of hits are : " << number_of_hits << endl;
    cout << "===========================================================================================" << endl;
}

long long int Prefix_Trie::traverseGenome(string kmer)
{
    stackNode *temp;
    top_of_stack = new stackNode;
    top_of_stack->node = root;
    top_of_stack->usedCharacters = "";
    top_of_stack->leftCharacters = kmer;
    top_of_stack->mismatches = 0;

    temp = top_of_stack;

    while (top_of_stack != NULL)
    {
        stackNode *current = top_of_stack;

        if (current->mismatches > 1)
        {
            top_of_stack = top_of_stack->next;
            delete current;

            continue;
        }

        else if (current->leftCharacters == "")
        {
            top_of_stack = top_of_stack->next;
            delete current;

            ++number_of_hits;
            continue;
        }

        char c = current->leftCharacters[0];

        if (current->node->A != NULL)
        {
            temp->next = new stackNode;
            temp = temp->next;
            temp->usedCharacters = current->usedCharacters + c;
            temp->leftCharacters = current->leftCharacters.substr(1, current->leftCharacters.length());
            temp->node = current->node->A;

            if (c == 'A')
                temp->mismatches = current->mismatches;

            else
                temp->mismatches = current->mismatches + 1;
        }

        if (current->node->C != NULL)
        {
            temp->next = new stackNode;
            temp = temp->next;
            temp->usedCharacters = current->usedCharacters + c;
            temp->leftCharacters = current->leftCharacters.substr(1, current->leftCharacters.length());
            temp->node = current->node->C;

            if (c == 'C')
                temp->mismatches = current->mismatches;

            else
                temp->mismatches = current->mismatches + 1;
        }

        if (current->node->G != NULL)
        {
            temp->next = new stackNode;
            temp = temp->next;
            temp->usedCharacters = current->usedCharacters + c;
            temp->leftCharacters = current->leftCharacters.substr(1, current->leftCharacters.length());
            temp->node = current->node->G;

            if (c == 'G')
                temp->mismatches = current->mismatches;

            else
                temp->mismatches = current->mismatches + 1;
        }

        if (current->node->T != NULL)
        {
            temp->next = new stackNode;
            temp = temp->next;
            temp->usedCharacters = current->usedCharacters + c;
            temp->leftCharacters = current->leftCharacters.substr(1, current->leftCharacters.length());
            temp->node = current->node->T;

            if (c == 'T')
                temp->mismatches = current->mismatches;

            else
                temp->mismatches = current->mismatches + 1;
        }

        top_of_stack = top_of_stack->next;

        delete current;
    }

    return number_of_hits;
}

// function to add a new word to the Trie
void Prefix_Trie::add(string word)
{
    TrieNode *current = root;
    char letter;

    for (int i = 0; i < 36; i++)
    {
        letter = word[i];

        if (letter == 'A')
        {
            if (current->A == NULL)
            {
                ++counter;
                current->A = new TrieNode;
            }
            current = current->A;
        }
        else if (letter == 'C')
        {
            if (current->C == NULL)
            {
                ++counter;
                current->C = new TrieNode;
            }
            current = current->C;
        }
        else if (letter == 'G')
        {
            if (current->G == NULL)
            {
                ++counter;
                current->G = new TrieNode;
            }
            current = current->G;
        }
        else if (letter == 'T')
        {
            if (current->T == NULL)
            {
                ++counter;
                current->T = new TrieNode;
            }
            current = current->T;
        }
    }
}

Prefix_Trie::~Prefix_Trie()
{
    // Destructor to destroy the object
    delete[] genome_buffer;
}