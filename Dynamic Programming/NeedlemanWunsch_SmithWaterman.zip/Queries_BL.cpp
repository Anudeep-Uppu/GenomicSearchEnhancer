#include <fstream>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <limits.h>
#include <cstdlib>
#include "Queries_BL.h"

using namespace std;

Queries_BL::Queries_BL()
{
	// object initialization happens here.
	twoMillion = new ListNode *[2000000];
}

void Queries_BL::create_matrix()
{
    nw_array[0][0] = 0;

    for(int i = 1; i < 17; i++, gap += -1) nw_array[0][i] = nw_array[i][0] = gap;
    
    gap = -1;
}

void Queries_BL::break_to_k_mers(long long int size, char *result_array)
{
    int j, index;
    
    for(long long int i = 0; i < size - 11 + 1; i++)
    {
		index = 0;

        for(j = i; j < 11 + i; j++)
        {
            k_mer_array[index] = result_array[j];
            index++;
        }
        k_mer_array[11] = '\0';

        insert_into_hashtable(i, k_mer_array);
    }
}

long long int Queries_BL::needleman_compare_nmer(char *query, char *genome_string)
{
    // This function performs a linear search in query buffer
    
	long long int k;
	int j = 0, nw_best_score = INT_MIN;
		
	for(int a = 1; a < 17; a++)
	{
	    for(int b = 1; b < 17; b++)
	    {
	        if(genome_string[a - 1] == query[b - 1])
	            nw_array[a][b] = nw_array[a - 1][b - 1] + match;
		      
	        else
	            nw_array[a][b] = max(nw_array[a - 1][b - 1] + mis_match, max(nw_array[a - 1][b] + gap, nw_array[a][b - 1] + gap));
	    }
	}
		
	nw_best_score = max(nw_best_score, nw_array[16][16]);

	// cout << "Query string : " << query << " genome string : " << genome_string << " Best score : " << nw_best_score << endl;
	
	return nw_best_score;
}

long long int Queries_BL::hash(long long int key, long long int size)
{
	return key % size;
}

long long int Queries_BL::getRadix(int charNumber, long long int i)
{
    long long int radixValue = 0;
    
    radixValue += charNumber * pow(5, 15 - i);
    
    return radixValue;
}

void Queries_BL::insert_into_hashtable(long long int index, char *query_array)
{
	long long int hash_index = 0;
	ListNode **temp = twoMillion;

	string str(query_array);

	int charNumber = 0;
	
	//cout << "Executed 8" << endl;

	for (int i = 0; i < 11; i++)
	{
		if (str[i] == 'A') charNumber = 0;
		else if (str[i] == 'C') charNumber = 1;
		else if (str[i] == 'G') charNumber = 2;
		else if (str[i] == 'T') charNumber = 3;
		else charNumber = 4;

		hash_index += getRadix(charNumber, i);
	}
	
	//cout << "Executed 9" << endl;

	hash_index = hash(hash_index, 2000000);
	
	//cout << "Executed 10" << endl;

	if (temp[hash_index] == NULL)
	{
		temp[hash_index] = new ListNode;
		temp[hash_index] -> fragment = str;
		temp[hash_index] -> genome_index = index;
		temp[hash_index] -> next = NULL;
	}
	
	else
	{
		ListNode *newNode = new ListNode;
		newNode -> fragment = str;
		newNode -> genome_index = index;
		newNode -> next = temp[hash_index];
		temp[hash_index] = newNode;
	}
}

long long int Queries_BL::search_fragment_query(char *fragment_array)
{
	long long int hash_index = 0;

	string str(fragment_array);

	int charNumber = 0;

	for (int i = 0; i < 11; i++)
	{
		if (str[i] == 'A') charNumber = 0;
		else if (str[i] == 'C') charNumber = 1;
		else if (str[i] == 'G') charNumber = 2;
		else if (str[i] == 'T') charNumber = 3;
		else charNumber = 4;

		hash_index += getRadix(charNumber, i);
	}

	hash_index = hash(hash_index, 2000000);

	if (twoMillion[hash_index] != NULL)
	{
		ListNode *temp = twoMillion[hash_index];

		while (temp != NULL)
		{
			if (temp -> fragment == str) return temp -> genome_index;

			temp = temp -> next;
		}
	}

	return -1;
}

Queries_BL::~Queries_BL()
{
	// This would be a destructor to destroy the object.
	
	for(long long int i = 0; i < 2000000; i++) delete[] twoMillion[i];
	
	delete twoMillion;

}