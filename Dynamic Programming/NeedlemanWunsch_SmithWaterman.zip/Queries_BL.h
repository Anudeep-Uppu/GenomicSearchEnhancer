#ifndef QUERIES_BL
#define QUERIES_BL

#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <limits.h>
#include <stdlib.h>

using namespace std;

class Queries_BL
{
	public:
	
	    struct ListNode 
        {
            string fragment;
            long long int genome_index;
            ListNode *next;
        };
        
        ListNode **twoMillion;
        
        int nw_array[17][17], gap = -1, mis_match = -1, match = 2;

        char k_mer_array[12];
		
		Queries_BL();
        
        void create_matrix();
        
        void break_to_k_mers(long long int size, char *result_array);
        		
        long long int needleman_compare_nmer(char *query, char *genome_string);
        
        long long int hash(long long int key, long long int size);
        
        long long int getRadix(int charNumber, long long int i);
        
        void insert_into_hashtable(long long int genome_index, char *query_array);
        
        long long int search_fragment_query(char *fragment_array);
        
        ~Queries_BL();
};
        
#endif
