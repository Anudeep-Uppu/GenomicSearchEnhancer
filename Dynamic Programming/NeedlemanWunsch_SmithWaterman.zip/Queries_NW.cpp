#include <fstream>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <limits.h>
#include <cstdlib>
#include "Queries_NW.h"

using namespace std;

char **query_buffer;
        
long long int genome_buffer_index, query_buffer_index, genome_buffer_size, query_buffer_size;
        
double total_time_taken = 0;
        
int nw_array[17][17], gap = -1, mis_match = -1, match = 2, count1 = 1, count2 = 1, count3 = 1, count4 = 1, count5 = 1, count6 = 1;

Queries_NW::Queries_NW()
{
	// object initialization happens here.
	genome_buffer_index = 0;
	query_buffer_index = 0;
	query_buffer_size = 0;
	genome_buffer_size = 0;
}

Queries_NW::Queries_NW(char *path1, char *path2)
{
	// This would be a custom constructor.
	genome_file_path = path1;
	query_file_path = path2;
}

long long int Queries_NW::find_genome_size()
{
	// This function finds the size of the entire human genome file excluding the scaffold headers.

	ifstream file_descriptor;

	file_descriptor.open(genome_file_path);

	string line;

	// If file open status is successful
	if (file_descriptor.good())
	{
		while (getline(file_descriptor, line))
		{
			if (line[0] == '>')
				continue;
			genome_buffer_size += line.length();
		}

		cout << "File size of genome data is " << genome_buffer_size << endl;

		file_descriptor.close();
	}

	// File open error occured
	else
		cout << "Failed to open the file." << endl;
		
	return genome_buffer_size;
}

void Queries_NW::read_genome_data()
{
	// This function reads the entire genome text file and performs the necessary operations

	ifstream file_descriptor;
	file_descriptor.open(genome_file_path);

	string line;

	if (file_descriptor.good())
	{
		genome_buffer = new char[genome_buffer_size];

		// Reads each and every line from the genome file and stores in buffer
		while (getline(file_descriptor, line))
		{
			if (line[0] != '>')
			{
				for (long long int k = 0; k < line.length(); k++)
					genome_buffer[genome_buffer_index++] = line[k];
			}
		}

		genome_buffer[genome_buffer_index] = '\0';

		file_descriptor.close();
	}

	else
		cout << "Failed to open the file." << endl;
}

long long int Queries_NW::find_query_dataset_size()
{
	// This function finds the size of the entire query dataset.

	ifstream file_descriptor;

	file_descriptor.open(query_file_path);

	string line;

	// If file open status is successful
	if (file_descriptor.good())
	{
		while (getline(file_descriptor, line))
		{
			if (line[0] == '>') 
			    continue;
			
			query_buffer_size += 1;
		}

		cout << "File size of query dataset is " << query_buffer_size << endl;
		
		cout << "==================================================================================================" << endl;

		file_descriptor.close();
	}

	// File open error occured
	else
		cout << "Failed to open the file." << endl;
		
	return query_buffer_size;
}

char** Queries_NW::read_query_dataset()
{
    // This function will read the entire query dataset into the buffer.
    
	ifstream file_descriptor;
  	file_descriptor.open(query_file_path);

  	string line;
  	
	if (file_descriptor.good()) 
	{
	    query_buffer = new char*[query_buffer_size];
	    int i;
	    
	    //Reads each and every line from the query file and stores in buffer
	    
	    while(getline(file_descriptor, line))
	    {	
	    	if(line[0] != '>')
	    	{
	    	    query_buffer[query_buffer_index] = new char[17];
	    	    
	    	    for(i = 0; i < 16; i++) query_buffer[query_buffer_index][i] = line[i];
	    	    
	    	    query_buffer[query_buffer_index][i] = '\0';
	    		
	    		query_buffer_index++;
			}		
		}
										
	    file_descriptor.close();
	} 
	
	else 
	    cout << "Failed to open the file." << endl;
	    
	return query_buffer;
}

void Queries_NW::create_matrix()
{
    nw_array[0][0] = 0;

    for(int i = 1; i < 17; i++, gap += -1) nw_array[0][i] = nw_array[i][0] = gap;
    
    gap = -1;
}

long long int Queries_NW::needleman_compare_nmer(int loop_counter, char *fragment_array)
{
    // This function performs a linear search in query buffer
    
	long long int k;
	int j = 0, nw_best_score = INT_MIN;
		
	for(k = 0; k < query_buffer_size; k++)
	{
		for(int a = 1; a < 17; a++)
		{
		    for(int b = 1; b < 17; b++)
		    {
		        if(fragment_array[a - 1] == query_buffer[k][b - 1])
		            nw_array[a][b] = nw_array[a - 1][b - 1] + match;
		      
		        else
		            nw_array[a][b] = max(nw_array[a - 1][b - 1] + mis_match, max(nw_array[a - 1][b] + gap, nw_array[a][b - 1] + gap));
		    }
		}
		
		nw_best_score = max(nw_best_score, nw_array[16][16]);
		
		if(nw_best_score >= 26)
        {
            if( (loop_counter == 0 && count1 == 1) || (loop_counter == 1 && count2 == 1) || (loop_counter == 2 && count3 == 1) || (loop_counter == 3 && count4 == 1) || (loop_counter == 4 && count5 == 1) || (loop_counter == 5 && count6 == 1) )
            {
                cout << "The best score is " << nw_best_score << endl;
                cout << "Found for string " << query_buffer[k] << " in query buffer" << endl;
            }
            
            if(loop_counter == 0) count1 = 0;
            else if(loop_counter == 1) count2 = 0;
            else if(loop_counter == 2) count3 = 0;
            else if(loop_counter == 3) count4 = 0;
            else if(loop_counter == 4) count5 = 0;
            else count6 = 0;
            
            return nw_best_score;
        }
	}
	
	return -1;
}

Queries_NW::~Queries_NW()
{
	// This would be a destructor to destroy the object.

	delete[] genome_buffer;
	delete[] query_buffer;
}