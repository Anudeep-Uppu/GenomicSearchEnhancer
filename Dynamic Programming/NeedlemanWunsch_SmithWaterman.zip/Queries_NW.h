#ifndef QUERIES_NW
#define QUERIES_NW

#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <limits.h>
#include <stdlib.h>

using namespace std;

class Queries_NW
{
	public:
	    
	    char *genome_buffer;
	    
	    char *genome_file_path, *query_file_path;
		
		Queries_NW();
		
		Queries_NW(char *path1, char *path2);
		
		long long int find_genome_size();
        
        void read_genome_data();
        
        long long int find_query_dataset_size();
        
        char** read_query_dataset();
        
        void create_matrix();
        		
        long long int needleman_compare_nmer(int loop_counter, char *fragment_array);
        
        ~Queries_NW();
};
        
#endif
