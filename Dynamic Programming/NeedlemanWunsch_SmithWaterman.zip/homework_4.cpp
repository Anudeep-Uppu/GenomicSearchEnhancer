#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <random>
#include <cstdlib>
#include "Queries_NW.h"
#include "Queries_BL.h"

using namespace std;

int main(int argc, char *argv[])
{
	string command = argv[1];
	char *path1 = argv[2], *path2 = argv[3];
	
	Queries_NW queries = Queries_NW(path1, path2);
	
	clock_t start_time, end_time;
	double total_time_taken = 0;
	
	int flag = 1;
	
	long long int genome_size = queries.find_genome_size();
	queries.read_genome_data();
	long long int query_buffer_size = queries.find_query_dataset_size();
	char **query_buffer_dataset = queries.read_query_dataset();
	queries.create_matrix();
	
	srand(time(0));
	
	long long int best_score = 0, best_hits = 0, size = 0, random_index = 0;
	char fragment_array[17];
	
	long long int random_number;
	string custom_random_string = "ACGT";
	    
	int x, y, z, p, q, r;
	
	if(command == "1")
	{
	    x = y = z = p = q = r = 1;
	    
	    cout << "Generating random indices using random function " << endl;
	    
	    for(int loop_counter = 0; loop_counter < 6; loop_counter++)
	    {
	        if(loop_counter == 0 || loop_counter == 3) size = 500;
	        else if(loop_counter == 1 || loop_counter == 4) size = 1000;
	        else size = 5000;
	        
	        if(loop_counter > 2) flag = 0;
	        
	        start_time = clock();
	    
    	    best_score = best_hits = 0;
    	    
    	    if(loop_counter == 3) cout << "Generating completely random indices using custom function " << endl;
                	
            for(long long int i = 0; i < size; i++)
            {
                if(flag == 1)
                {
                    random_number = rand() % (size + 1);
                    
                    for(int j = 0; j < 16; j++) fragment_array[j] = queries.genome_buffer[random_number + j];
                    
                    fragment_array[16] = '\0';
                    
                    best_score = queries.needleman_compare_nmer(loop_counter, fragment_array); 
                }
                else
                {
                    for (int j = 0, a = 0; a < 16; a++, j++) 
                    {
                        random_number = rand() % 4;
                        fragment_array[j] = custom_random_string[random_number];
                    }
                    fragment_array[16] = '\0';
                    
                    best_score = queries.needleman_compare_nmer(loop_counter, fragment_array);
                }
                
                if(best_score >= 26)
                {
                    if( (loop_counter == 0 && x == 1) || (loop_counter == 1 && y == 1) || (loop_counter == 2 && z == 1) || (loop_counter == 3 && p == 1) || (loop_counter == 4 && q == 1) || (loop_counter == 5 && r == 1) )
                    {
                        if(flag == 1) cout << "Found for string " << fragment_array << " in genome buffer" << endl;
                        else cout << "Found for string " << fragment_array << " which was generated completely random " << endl;
                    }
                    
                    if(loop_counter == 0) x = 0;
                    else if(loop_counter == 1) y = 0;
                    else if(loop_counter == 2) z = 0;
                    else if(loop_counter == 3) p = 0;
                    else if(loop_counter == 4) q = 0;
                    else r = 0;
                    
                    ++best_hits;
                }
            }
                	
            end_time = clock();
            		
            total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
            
            if(best_score == -1) cout << "No such match exists" << endl;
            
            cout << "Total number of hits observed in " << size << " n-mers are " << best_hits << endl;
            
            cout << "Total time taken for searching all hits for " << size << " n-mers are " << total_time_taken << " seconds" << endl;
            
            cout << "==================================================================================================" << endl;
    	}
	}
    	
	else
	{
	    Queries_BL queries_bl = Queries_BL();
	    queries_bl.create_matrix();
	    
	    x = y = z = p = q = r = 1;
	    flag = 1;
	    
	    char *result_array = new char[1000000];
	    char match_string[17];
	    
	    cout << "Using BLAST WAY" << endl;
	    cout << "Generating random indices using random function " << endl;
	    
	    for(int loop_counter = 0; loop_counter < 6; loop_counter++)
	    {
	        start_time = clock();
	        
	        if(loop_counter == 0 || loop_counter == 3) size = 500;
	        else if(loop_counter == 1 || loop_counter == 4) size = 1000;
	        else size = 10000;
	        
	        if(loop_counter == 3) 
	        {
	            flag = 0;
	            x = y = z = p = q = r = 1;
	            cout << "Generating completely random indices using custom function " << endl;
	        }
	        
    	    best_score = best_hits = 0;
    	    
    	    long long int j, index_of_genome, index;
                	
            for(long long int i = 0; i < size; i++)
            {
                if(flag == 1)
                {
                    random_number = rand() % (genome_size - size);
                    
                    for(index = 0, j = random_number; j < random_number + size; j++)
                    {
                        result_array[index] = queries.genome_buffer[j];
                        index++;
                    }
                }
                
                else
                {
                    for (long long int result_array_index = 0, a = 0; a < size; a++, result_array_index++)
                    {
                        random_number = rand() % 4;
                        result_array[result_array_index] = custom_random_string[random_number];
                    }
                }

                queries_bl.break_to_k_mers(size, result_array);
                    
                for(index = 0; index < query_buffer_size; index++)
                {
                    for(int k_mer_count = 0; k_mer_count < 6; k_mer_count++) // 16 - 11 + 1 iterations
                    {
                        int b = 0, a;
                        for (a = k_mer_count; a < 11 + k_mer_count; a++)
                        {
                            queries_bl.k_mer_array[b] = query_buffer_dataset[index][a];
                            b++;
                        }
                        queries_bl.k_mer_array[11] = '\0';
                        
                        index_of_genome = queries_bl.search_fragment_query(queries_bl.k_mer_array);
                        
                        if(index_of_genome != -1)
                        {
                            int match_string_index = 0, genome_index_iterator;

                            for (genome_index_iterator = index_of_genome - k_mer_count; genome_index_iterator < index_of_genome - k_mer_count + 16; match_string_index++)
                            {
                                match_string[match_string_index] = queries.genome_buffer[genome_index_iterator];
                                genome_index_iterator++;
                            }
                            match_string[16] = '\0';
                            
                            best_score = queries_bl.needleman_compare_nmer(query_buffer_dataset[index], match_string);
                            
                            if(best_score >= 26)
                            {
                                if( (loop_counter == 0 && x == 1) || (loop_counter == 1 && y == 1) || (loop_counter == 2 && z == 1) || (loop_counter == 3 && p == 1) || (loop_counter == 4 && q == 1) || (loop_counter == 5 && r == 1) )
                                {
                                    cout << "The best score is " << best_score << endl;
                                    cout << "Found for string " << query_buffer_dataset[index] << " in query buffer" << endl;
                                    cout << "Found for string " << match_string << " in genome buffer" << endl;
                                }
                                
                                if(loop_counter == 0) x = 0;
                                else if(loop_counter == 1) y = 0;
                                else if(loop_counter == 2) z = 0;
                                else if(loop_counter == 3) p = 0;
                                else if(loop_counter == 4) q = 0;
                                else r = 0;
                                
                                ++best_hits;
                            }
                        }
                    }
                }
            }
            
            end_time = clock();
            
            total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
            
            cout << "Total number of hits observed in " << size << " n-mers are " << best_hits << endl;

            cout << "Total time taken for searching all hits for " << size << " n-mers are " << total_time_taken << " seconds" << endl;

            cout << "==================================================================================================" << endl;
	    }
    }
}