#include <fstream>
#include <iostream>
#include <climits>
#include <time.h>
#include "genome_header.h"

using namespace std;

void find_size()
{
	// This function finds the size of the entire human genome file excluding the scaffold headers.
	
	ifstream file_descriptor;
	
	cout<<"find_size function"<<endl;
	cout<<file_path<<endl;
	
  	file_descriptor.open(file_path);
  	
  	string line;
  	
  	//If file open status is successful
	if (file_descriptor.good()) 
	{   
	    while(getline(file_descriptor, line))
	    {
	    	if(line[0] == '>') continue;
	    	size += line.length();
		}
	    
		cout << "File size is " << size << endl;	
	
	    file_descriptor.close();
	} 
	
	// File open error occured
	else 
	    cout << "Failed to open the file." << endl;
}

void read_genome_data()
{
	// This function reads the entire genome text file and performs the necessary operations
	
	ifstream file_descriptor;
  	file_descriptor.open(file_path);

  	string line, header;
  	string minimum_length_scaffold, maximum_length_scaffold;
  	long long int maximum_length, minimum_length, max_index = 0, min_index = 0, average_length;
  	maximum_length = LLONG_MIN;
	minimum_length = LLONG_MAX;
  	
	if (file_descriptor.good()) 
	{
	    buffer = new char[size];
	    scaffold_array = new long long int [size];
	    
	    //Reads each and every line and maintains a count of all the scaffolds
	    while(getline(file_descriptor, line))
	    {	
	    	if(line[0] == '>') 
	    	{
	            scaffold_counter++;
	    		scaffold_array[scaffold_array_index++] = length_of_scaffold;
	    		
	    		if(length_of_scaffold != -1 && length_of_scaffold < minimum_length)
	    		{
	    		    minimum_length = length_of_scaffold;
	    		    minimum_length_scaffold = header;
	    		    min_index = scaffold_array_index;
	    		}
	    		
	    		if(length_of_scaffold > maximum_length)
	    		{
	    		    maximum_length = length_of_scaffold;
	    		    maximum_length_scaffold = header;
	    		    max_index = scaffold_array_index;
	    		}
	    		header = line;
	    		length_of_scaffold = 0;
	    		continue;
			}
			
			length_of_scaffold += line.length();
			
			for(long long int k = 0; k < line.length(); k++)
				buffer[buffer_index++] = line[k];
				
		}
		
		average_length = size / (scaffold_counter - 1);
		
		cout << "=======================================================================================" << endl;
		cout << "The number of scaffolds are " << scaffold_counter - 1 << endl;
		cout << "Maximum scaffold length is " << maximum_length << " for scaffold number " << max_index - 1 << " for scaffold name " << maximum_length_scaffold << endl;
	    cout << "Minimum scaffold length is " << minimum_length << " for scaffold number " << min_index - 1 << " for scaffold name " << minimum_length_scaffold << endl;
	    cout << "Average scaffold length is " << average_length << endl;
		
		scaffold_array[scaffold_array_index] = length_of_scaffold;
		
		buffer[buffer_index] = '\0';
		
	    file_descriptor.close();
	} 
	
	else 
	    cout << "Failed to open the file." << endl;
}

void compute_characters()
{	
	//This function will count the number of A's, C's, G's and T's in human genome data
	
	a_counter = c_counter = g_counter = t_counter = scaffolds = 0;
	
	for(long long int i = 0; buffer[i] != '\0'; i++)
	{
		if(buffer[i] == 'A') ++a_counter;
		else if(buffer[i] == 'G') ++g_counter;
		else if(buffer[i] == 'C') ++c_counter;
		else if(buffer[i] == 'T') ++t_counter;
	}
	
	cout << "=======================================================================================" << endl;
	cout << "The number of A's are " << a_counter << endl;
	cout << "The number of G's are " << g_counter << endl;
	cout << "The number of C's are " << c_counter << endl;
	cout << "The number of T's are " << t_counter << endl;
	cout << "=======================================================================================" << endl;
	
}


void gc_content()
{
	//This function will find out the percentage content of G and C in human genome data
	
	double c_percentage, g_percentage;
	double total_counter = a_counter + c_counter + g_counter + t_counter;

	c_percentage = (c_counter * 100) / (double)size;
	g_percentage = (g_counter * 100) / (double)size;
	
	cout << "The percentage of C in entire human genome is " << c_percentage << "%" << endl;
	cout << "The percentage of G in entire human genome is " << g_percentage << "%" <<endl;
	cout << "The percentage of GC in entire human genome is " << g_percentage + c_percentage << "%" <<endl;
	cout << "============================================================================" << endl;
}

int main(int argc, char *argv[]) 
{
	file_path = argv[1];
		
	string command = argv[2];
	
	clock_t start_time, end_time;
	double total_time_taken;
	
	if(command=="1")
	{
		//cout<<"Test"<<endl;
		find_size();
		read_genome_data();		
	}
	
	if(command == "2")
	{
	    start_time = clock();
	    
		find_size();
		read_genome_data();
		compute_characters();
		gc_content();
		
		end_time = clock();
		
		total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
		
		cout << "Total time taken for program execution is " << total_time_taken << " seconds" << endl;
	}

  return 0;
}

