char *buffer, *file_path;
long long int scaffold_counter = 1;
long long int buffer_index = 0;
long long int a_counter, c_counter, g_counter, t_counter, scaffolds;
long long int length_of_scaffold = -1, scaffold_array_index = 0;
long long int *scaffold_array;
long long int size = 0;
