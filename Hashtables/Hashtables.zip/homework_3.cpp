#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include "Queries_HT.h"

using namespace std;

int main(int argc, char *argv[])
{
	string command = argv[1];
	char *path1 = argv[2], *path2 = argv[3];
	
	Queries_HT queries = Queries_HT(path1, path2);
	
	long long int size = 0;
	
	long long int genome_size = queries.find_genome_size();
	queries.read_genome_data();
	queries.find_query_dataset_size();
	
	long long int oneMillionCount, tenMillionCount, thirtyMillionCount, sixtyMillionCount;
	
	oneMillionCount = 1000000;
	tenMillionCount = 10000000;
	thirtyMillionCount = 30000000;
	sixtyMillionCount = 60000000;
	
	for(int i = 0; i < 4; i++)
    {
        if(i == 0) size = oneMillionCount;
        else if(i == 1) size = tenMillionCount;
        else if(i == 2) size = thirtyMillionCount;
        else size = sixtyMillionCount;
    	    
        queries.createHashTable(i, size);
        queries.read_query_dataset(i, size);
    } 
    
    cout << "===========================================================================================================" << endl;
	
	if(command == "1")
	{
	    for(int i = 0; i < 4; i++)
    	{
    	    if(i == 0) size = oneMillionCount;
    	    else if(i == 1) size = tenMillionCount;
    	    else if(i == 2) size = thirtyMillionCount;
    	    else size = sixtyMillionCount;
    	    
    	    cout << "Number of collisions occured for an hashtable of size " << size << " are " << queries.collisions(i) << endl;
    	    cout << "===========================================================================================================" << endl;
    	} 
	}
    	
	else
	{
    	long long int fragment_count = 1, total_number_of_fragments = 0;
    	
    	clock_t start_time, end_time;
	    double total_time_taken = 0;
	    
	    bool index = false;
	    char fragment_array[17];
	        
    	start_time = clock();
    	    
        cout << "First 10 matching fragments in hashtable of size " << sixtyMillionCount << " are :" << endl << endl;
            	
        for(long long int i = 0; i < genome_size - 16; i++)
        {
        	index = queries.search_fragment(i, fragment_array);
        	
        	if(index == true)
        	{
        	    //cout << "I m here" << endl;
        	    if(fragment_count <= 10)
        	    {
            	    string str(fragment_array);
            	    cout << fragment_count << " Matching fragment in genome data at index " << i << " is : " << str << endl;
            	    ++fragment_count;
            	    //cout << fragment_count << endl;
        	    }
        	    ++total_number_of_fragments;
        	}
        }
        
        cout << "===========================================================================================================" << endl;
        
        cout << "Total number of fragment hits are " << total_number_of_fragments << endl;
            
        cout << "===========================================================================================================" << endl;
            	
        end_time = clock();
        		
        total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
        	
        cout << "Total time taken for finding all the fragments of genome data in hashtable of size " << sixtyMillionCount << " are " << total_time_taken << " seconds" << endl;
	}
}
