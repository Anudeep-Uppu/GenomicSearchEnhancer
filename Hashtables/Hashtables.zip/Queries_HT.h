#ifndef QUERIES_HT
#define QUERIES_HT

#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include <stdlib.h>

using namespace std;

class Queries_HT
{
	public:
	
	    struct ListNode 
        {
            string fragment;
            ListNode *next;
        };
              
        ListNode **oneMillion, **tenMillion, **thirtyMillion, **sixtyMillion;
	
	public:
		char *genome_file_path;
		char *query_file_path;
		
		Queries_HT();
        		
        Queries_HT(char *path1, char *path2);
        
        long long int find_genome_size();
        
        void read_genome_data();
        
        void find_query_dataset_size();
        
        void read_query_dataset(int counter, long long int size);
        
        bool search_fragment(long long int i, char *fragment_array);
        
        void createHashTable(int i, long long int size);
        
        long long int hash(long long int key, long long int size);
        
        long long int collisions(int i);
        
        long long int getRadix(int charNumber, long long int i);
        
        ~Queries_HT();
};
        
#endif
