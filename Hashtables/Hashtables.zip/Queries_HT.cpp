#include <fstream>
#include <stdlib.h>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include <cmath>
#include "Queries_HT.h"

using namespace std;

double total_time_taken = 0;

long long int collision_count_index = 0;
int collision_count_array[4];

char *genome_buffer;
long long int genome_buffer_index;
long long int genome_buffer_size, query_buffer_size;

Queries_HT::Queries_HT()
{
	// object initialization happens here.
	genome_buffer_index = 0;
	query_buffer_size = 0;
	genome_buffer_size = 0;
}

Queries_HT::Queries_HT(char *path1, char *path2)
{
	// This would be a custom constructor.
	genome_file_path = path1;
	query_file_path = path2;
}

long long int Queries_HT::find_genome_size()
{
	// This function finds the size of the entire human genome file excluding the scaffold headers.

	ifstream file_descriptor;

	file_descriptor.open(genome_file_path);

	string line;

	// If file open status is successful
	if (file_descriptor.good())
	{
		while (getline(file_descriptor, line))
		{
			if (line[0] == '>')
				continue;
			genome_buffer_size += line.length();
		}

		cout << "File size of genome data is " << genome_buffer_size << endl;

		file_descriptor.close();
	}

	// File open error occured
	else
		cout << "Failed to open the file." << endl;
		
	return genome_buffer_size;
}

void Queries_HT::read_genome_data()
{
	// This function reads the entire genome text file and performs the necessary operations

	ifstream file_descriptor;
	file_descriptor.open(genome_file_path);

	string line;

	if (file_descriptor.good())
	{
		genome_buffer = new char[genome_buffer_size];

		// Reads each and every line from the genome file and stores in buffer
		while (getline(file_descriptor, line))
		{
			if (line[0] != '>')
			{
				for (long long int k = 0; k < line.length(); k++)
					genome_buffer[genome_buffer_index++] = line[k];
			}
		}

		genome_buffer[genome_buffer_index] = '\0';

		file_descriptor.close();
	}

	else
		cout << "Failed to open the file." << endl;
}

void Queries_HT::find_query_dataset_size()
{
	// This function finds the size of the entire query dataset.

	ifstream file_descriptor;

	file_descriptor.open(query_file_path);

	string line;
	query_buffer_size = 0;

	// If file open status is successful
	if (file_descriptor.good())
	{
		while (getline(file_descriptor, line))
		{
			if (line[0] == '>')
				continue;
			query_buffer_size += 1;
		}

		cout << "File size of query dataset is " << query_buffer_size << endl;
		cout << "===========================================================================================================" << endl;

		file_descriptor.close();
	}

	// File open error occured
	else
		cout << "Failed to open the file." << endl;
}

void Queries_HT::createHashTable(int i, long long int size)
{
	if (i == 0) oneMillion = new ListNode *[size];
	else if (i == 1) tenMillion = new ListNode *[size];
	else if (i == 2) thirtyMillion = new ListNode *[size];
	else sixtyMillion = new ListNode *[size];
}

long long int Queries_HT::hash(long long int key, long long int size)
{
	return key % size;
}

long long int Queries_HT::collisions(int i)
{
	if (i == 0) return collision_count_array[0];
	else if (i == 1) return collision_count_array[1];
	else if (i == 2) return collision_count_array[2];
	return collision_count_array[3];
}

long long int Queries_HT::getRadix(int charNumber, long long int i)
{
    long long int radixValue = 0;
    
    radixValue += charNumber * (long long int)pow(5, 15 - i);
    
    return radixValue;
}

void Queries_HT::read_query_dataset(int counter, long long int size)
{
	// This function will read the entire query dataset into the buffer.

	ifstream file_descriptor;
	file_descriptor.open(query_file_path);

	clock_t start_time, end_time;

	ListNode **temp = NULL;

	if (counter == 0) temp = oneMillion;
	else if (counter == 1) temp = tenMillion;
	else if (counter == 2) temp = thirtyMillion;
	else temp = sixtyMillion;

	string line;
	int charNumber = 0;
	long long int query_buffer_index = 0;

	if (file_descriptor.good())
	{
		start_time = clock();

		while (getline(file_descriptor, line))
		{
			if (line[0] != '>')
			{
			    query_buffer_index = 0;
			    
				for (int i = 0; i < 16; i++)
				{
					if (line[i] == 'A') charNumber = 0;
					else if (line[i] == 'C') charNumber = 1;
					else if (line[i] == 'G') charNumber = 2;
					else if (line[i] == 'T') charNumber = 3;
					else charNumber = 4;

					query_buffer_index += getRadix(charNumber, i);
				}

				query_buffer_index = hash(query_buffer_index, size);
				
				if (temp[query_buffer_index] == NULL)
				{
					temp[query_buffer_index] = new ListNode;
					temp[query_buffer_index] -> fragment = line;
					temp[query_buffer_index] -> next = NULL;
				}
				else
				{
					++collision_count_array[counter];
					ListNode *newNode = new ListNode;
					newNode -> fragment = line;
					newNode -> next = temp[query_buffer_index];
					temp[query_buffer_index] = newNode;
				}
			}
		}

		end_time = clock();
		total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);

		cout << "Total time taken for building the hash table of size " << size << " is " << total_time_taken << " seconds" << endl;

		file_descriptor.close();
	}

	else
		cout << "Failed to open the file." << endl;
}

bool Queries_HT::search_fragment(long long int index, char *fragment_array)
{
	long long int hash_index = 0;
	int j;

	for (j = 0; j < 16; j++)
	{
		fragment_array[j] = genome_buffer[index];
		index++;
	}
	fragment_array[j] = '\0';

	string str(fragment_array);

	int charNumber = 0;

	for (int i = 0; i < 16; i++)
	{
		if (str[i] == 'A') charNumber = 0;
		else if (str[i] == 'C') charNumber = 1;
		else if (str[i] == 'G') charNumber = 2;
		else if (str[i] == 'T') charNumber = 3;
		else charNumber = 4;

		hash_index += getRadix(charNumber, i);
	}

	hash_index = hash(hash_index, 60000000);

	if (sixtyMillion[hash_index] != NULL)
	{
		ListNode *temp = sixtyMillion[hash_index];

		while (temp != NULL)
		{
			if (temp -> fragment == str) return true;

			temp = temp -> next;
		}
	}

	return false;
}

Queries_HT::~Queries_HT()
{
	// This would be a destructor to destroy the object.

	delete[] genome_buffer;
}