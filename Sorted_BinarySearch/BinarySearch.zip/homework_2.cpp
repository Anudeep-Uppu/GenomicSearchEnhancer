#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include "Queries.h"

using namespace std;

int main(int argc, char *argv[])
{
	string command = argv[1];
	char *path1 = argv[2], *path2 = argv[3];
	
	Queries_AR queries = Queries_AR(path1, path2);
	
	long long int fragment_count = 0;
	long long int size = 0;
	char fragment_array[33];
	long long int index = 0;
	
	clock_t start_time, end_time, end_time1, end_time2;
	double total_time_taken = 0;
	
	queries.find_genome_size();
	queries.read_genome_data();
	queries.find_query_dataset_size();
	queries.read_query_dataset();
	
	//size = genome_buffer_size - 32;
    	
	if(command == "1")
	{
	    	for(int p = 0; p < 3; p++)
    		{
    		    if(p == 0) size = 10000;
    	        else if(p == 1) size = 100000;
    	        else size = 1000000;
    	        
    	        fragment_count = 0;
	        
    	        start_time = clock();
    	    
            	cout << "=======================================================" << endl;
            	cout << "First 10 matching fragments in " << size << " fragments are " << endl << endl;
            	
            	for(long long int i = 0; i < size; i++)
            	{
            		index = queries.search_fragment(i, fragment_array);
            		if(index != -1 && ++fragment_count <= 10)
            			cout << "Matching index in genome data : " << index << endl;
            			
            		/*if(i == (10000-1))
            		{
            		    end_time1=clock();
    	        	    total_time_taken = double(end_time1 - start_time) / double(CLOCKS_PER_SEC);
        		
        		        cout << "Total time taken for program execution with out sorting for " << i << " fragments are " << total_time_taken << " seconds" << endl;
            		}
            		
            		if(i == (100000-1))
            		{
            		    end_time2=clock();
    	        	    total_time_taken = double(end_time2 - start_time) / double(CLOCKS_PER_SEC);
        		
        		        cout << "Total time taken for program execution with out sorting for " << i << " fragments are " << total_time_taken << " seconds" << endl;
            		}*/
            		
            		else if(fragment_count > 10) break;
            	}
            	
            	cout << "=======================================================" << endl;
            	
            	end_time = clock();
        		
        	    total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
        		
        		//cout << "Total time taken for program execution with out sorting for " << size << " fragments are " << total_time_taken << " seconds" << endl;
    	    }
	}
	
	else
	{
		queries.merge_sort_fragment(0, queries.query_buffer_size - 1);
		
		for(int p = 0; p < 3; p++)
		{
		    if(p == 0) size = 10000;
	        else if(p == 1) size = 100000;
	        else size = 1000000;
	        
		    start_time = clock();
	
        	cout << "Sorting and applying binary search" << endl << endl;
        	cout << "=======================================================" << endl;
        	cout << "First 10 matching fragments in " << size << " fragments are " << endl << endl;
        	
        	fragment_count = 0;
        	
        	for(long long int i = 0; i < size; i++)
        	{
        	    index = queries.binary_search(i, fragment_array);
        		
        		if(index != -1 && ++fragment_count <= 10)
        			cout << "Matching index in genome data : " << index << endl;
        		
        		//else if(fragment_count > 10) break;
        	}
        	
        	end_time = clock();
    		
    		total_time_taken = double(end_time - start_time) / double(CLOCKS_PER_SEC);
    		
    		cout << "Total time taken for program execution after sorting for " << size << " fragments are " << total_time_taken << " seconds" << endl;
    		cout << "=======================================================" << endl;
		}
	}
}
