#ifndef Queries_H
#define Queries_H


class Queries_AR
{
	public:
        char *genome_buffer;
        char **query_buffer;
        long long int genome_buffer_index, query_buffer_index;
        long long int genome_buffer_size, query_buffer_size;
        
		char *genome_file_path, *query_file_path;
		
	    Queries_AR();
        		
        Queries_AR(char *path1, char *path2);
        
        void find_genome_size();
        
        void read_genome_data();
        
        void find_query_dataset_size();
        
        void read_query_dataset();
        
        long long int search_fragment(long long int i, char *fragment_array);
        
        void merge_sort_fragment(long long int left, long long int right);
        
        void merge(long long int left, long long int mid, long long int right);
        
        long long int binary_search(long long int i, char *fragment_array);
        
        ~Queries_AR();
};
        
#endif
