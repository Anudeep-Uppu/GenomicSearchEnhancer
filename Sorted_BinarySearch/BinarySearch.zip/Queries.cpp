#include <fstream>
#include <cstring>
#include <iostream>
#include <time.h>
#include <string>
#include <algorithm>
#include "Queries.h"

using namespace std;
        
Queries_AR::Queries_AR()
{
	//object initialization happens here.
	query_buffer_index = 0;
	query_buffer_size = 0;
	genome_buffer_size = 0;
			
}
		
Queries_AR::Queries_AR(char *path1, char *path2)
{
	//This would be a custom constructor.
	genome_file_path = path1;
	query_file_path = path2;
}

void Queries_AR::find_genome_size()
{
	// This function finds the size of the entire human genome file excluding the scaffold headers.
	
	ifstream file_descriptor;
	
  	file_descriptor.open(genome_file_path);
  	
  	string line;
  	
  	//If file open status is successful
	if (file_descriptor.good()) 
	{   
	    while(getline(file_descriptor, line))
	    {
	    	if(line[0] == '>') continue;
	    	genome_buffer_size += line.length();
		}
	    
		cout << "File size of genome data is " << genome_buffer_size << endl;	
	
	    file_descriptor.close();
	} 
	
	// File open error occured
	else 
	    cout << "Failed to open the file." << endl;
}

void Queries_AR::read_genome_data()
{
	// This function reads the entire genome text file and performs the necessary operations
	
	ifstream file_descriptor;
  	file_descriptor.open(genome_file_path);

  	string line;
  	
	if (file_descriptor.good()) 
	{
	    genome_buffer = new char[genome_buffer_size];
	    
	    //Reads each and every line from the genome file and stores in buffer
	    while(getline(file_descriptor, line))
	    {	
	    	if(line[0] != '>')
	    	{
	    		for(long long int k = 0; k < line.length(); k++)
					genome_buffer[genome_buffer_index++] = line[k];
			}
				
		}
						
		genome_buffer[genome_buffer_index] = '\0';
		
	    file_descriptor.close();
	} 
	
	else 
	    cout << "Failed to open the file." << endl;
}

void Queries_AR::find_query_dataset_size()
{
	// This function finds the size of the entire query dataset.
	
	ifstream file_descriptor;
	
  	file_descriptor.open(query_file_path);
  	
  	string line;
  	
  	//If file open status is successful
	if (file_descriptor.good()) 
	{   
	    while(getline(file_descriptor, line))
	    {
	    	if(line[0] == '>') continue;
	    	query_buffer_size += 1;
		}
	    
		cout << "File size of query dataset is " << query_buffer_size << endl;	
	
	    file_descriptor.close();
	} 
	
	// File open error occured
	else 
	    cout << "Failed to open the file." << endl;
}

void Queries_AR::read_query_dataset()
{
    // This function will read the entire query dataset into the buffer.
    
	ifstream file_descriptor;
  	file_descriptor.open(query_file_path);

  	string line;
  	
	if (file_descriptor.good()) 
	{
	    query_buffer = new char*[query_buffer_size];
	    long long int i;
	    
	    //Reads each and every line from the genome file and stores in buffer
	    
	    while(getline(file_descriptor, line))
	    {	
	    	if(line[0] != '>')
	    	{
	    	    query_buffer[query_buffer_index] = new char[33];
	    	    
	    	    for(i = 0; i < 32; i++)
	    	    {
	    	        query_buffer[query_buffer_index][i] = line[i];
	    	    }
	    		//cout << query_buffer[query_buffer_index] << endl;
	    		query_buffer[query_buffer_index][i] = '\0';
	    		query_buffer_index++;
			}		
		}
										
	    file_descriptor.close();
	} 
	
	else 
	    cout << "Failed to open the file." << endl;
}

long long int Queries_AR::search_fragment(long long int i, char *fragment_array)
{
    // This function performs a linear search in an unsorted query buffer
    
	long long int index = i;
	int j;
	
	for(j = 0; j < 32; j++)
	{
		fragment_array[j] = genome_buffer[index];
		index++;
	}
	fragment_array[j] = '\0';
	
	string str(fragment_array);
		
	for(long long int k = 0; k < query_buffer_size; k++)
	{
	    string converted(query_buffer[k]);
	    
		if(str.compare(converted) == 0)
		{
			//cout << str << "-> " << query_buffer[k] <<endl;
			return i;
		}
	}
	
	return -1;
}

void Queries_AR::merge_sort_fragment(long long int left, long long int right)
{
    // This function sorts the query data buffer
	
	//sort(query_buffer, query_buffer + query_buffer_size, [](const char* a, const char* b){ return strcmp(a, b) < 0; });
	
    if(left < right)
    {
        int mid = left + (right - left) / 2;
        
        merge_sort_fragment(left, mid);
        merge_sort_fragment(mid + 1, right);
        
        merge(left, mid, right);
    }
}

void Queries_AR::merge(long long int left, long long int mid, long long int right)
{
    // This function will merge left and right arrays of the mergesort algorithm.
    
    long long int first_array_size = mid - left + 1;
    long long int second_array_size = right - mid;
    
    char first_array[first_array_size][32];
    char second_array[second_array_size][32];
    
    long long int i, j, k;
    
    for(i = 0; i < first_array_size; i++)
        strcpy(first_array[i], query_buffer[left + i]);
        
    for(j = 0; i < second_array_size; j++)
        strcpy(second_array[i], query_buffer[mid + 1 + i]);
        
    i = j = 0;
    k = left;
    
    while(i < first_array_size && j < second_array_size)
    {
        if(strcmp(first_array[i], second_array[j]) <= 0)
        {
            strcpy(query_buffer[k], first_array[i]);
            i++;
        }
        else
        {
            strcpy(query_buffer[k], second_array[j]);
            j++;
        }
        
        k++;
    }
    
    while(i < first_array_size)
    {
        strcpy(query_buffer[k], first_array[i]);
        i++;
        k++;
    }
    
    while(j < second_array_size)
    {
        strcpy(query_buffer[k], second_array[j]);
        j++;
        k++;
    }
}

long long int Queries_AR::binary_search(long long int i, char *fragment_array)
{
    // This function will perform a binary search on a sorted query dataset.
    
    //cout <<"1" << endl;
	long long int index = i, j;
	for(j = 0; j < 32; j++)
	{
		fragment_array[j] = genome_buffer[index];
		index++;
	}
	//cout << "2" << endl;
	fragment_array[j] = '\0';
	
	string str = string(fragment_array);
	
	long long int start = 0, end = query_buffer_size - 1;
	
	//cout << "3" << endl;
	long long int mid = 0;
	
	while(start <= end)
	{
		mid = start + (end - start) / 2;
		string converted(query_buffer[mid]);
		
		if(str == converted)
		{
			//cout << str << "-> " << query_buffer[mid] << endl;
			return i;
		}
		
		else if(str < converted)
			end = mid - 1;
		else
			start = mid + 1;
	}
	
	//cout << "4" << endl;
	return -1;
}

Queries_AR::~Queries_AR()
{
	//This would be a destructor to destroy the object.
 	    
	delete[] genome_buffer;
	
 	for(long long int i = 0; i < query_buffer_size; i++)
 	    delete[] query_buffer[i];
	
	delete[] query_buffer;
}